<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Intellipharm Report</title>

        <!-- Bootstrap core CSS -->
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/small-business.css" rel="stylesheet">

    </head>

    <body>
        <?php
       
             // Database configuration
            $host = "127.0.0.1"; /* Host name */
            $user = "root"; /* User */
            $password = ""; /* Password */
            $dbname = "member"; /* Database name */

            $con = mysqli_connect($host, $user, $password,$dbname);
            // Check connection
            if (!$con) {
              die("Connection failed: " . mysqli_connect_error());
            }
           $sql = mysqli_query($con,"select * from members order by id desc");

           //JSON array declaration
           $members = array();

           while ($row = mysqli_fetch_assoc($sql)) {
                //$members = $row ;
                $members[] = array (
                    "firstname" => $row['firstname'],
                    "surname" => $row['surname'],
                    "email" => $row['email'],
                    "gender"=> $row['gender'],
                    "joined_date"=> $row['joined_date']
                );
           }
            json_encode(array ('members' => $members));
            $file_name = 'members.json';

        //Get Year list
        $sql_year = "SELECT DISTINCT YEAR(`joined_date`) as Year FROM `members` GROUP BY YEAR(`joined_date`)";
        $result_year = $con->query($sql_year);

        //Number of sign-ups each year 
        $sql_signup_per_year = "SELECT YEAR(`joined_date`) as Year,COUNT(`joined_date`) as NewSignUps FROM `members` GROUP BY YEAR(`joined_date`)";
        $result_yearly_signup = $con->query($sql_signup_per_year);
       
        ?>

        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#">Intellipharm Report</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a>Report Generator</a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>

        <!-- Page Content -->
        <div class="container">

            <div class="row my-4">
                <div class="col-md-12">
                    </br></br></br>
                    <form class="form-horizontal" method="POST">
                        <fieldset>

                            <!-- Select Basic -->
                            <div class="form-group">
                                <label class="row col-md-4 control-label" for="select">Select parameters to generate report</label>
                                <div class="row col-md-12">
                                    <table border="0" cellpadding="10">
                                        <tr>
                                            <th width="25%">Year</th>
                                        </tr>
                                        <tr>
                                            <td width="25%">

                                                <select id="selectyear" name="selectyear" class="form-control">
                                                    <option value="-1">---SELECT YEAR---</option>
                                                    <?php
                                                    while ($row = $result_year->fetch_array()) {
                                                        echo "<option id=\"{$row['Year']}\" value=\"{$row['Year']}\">";
                                                        echo $row['Year'];
                                                        echo "</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </td>
                                            
                                            <!-- Button -->
                                            <td width="25%">
                                                <button type="submit" name="generate" class="btn btn-primary" onclick="showDiv()">Generate Report</button>
                                            </td>
                                        </tr>
                                        <script type="text/javascript">
                                            function showDiv() {
                                                document.getElementById('table').style.display = "block";
                                            }
                                        </script>

                                    </table>
                                    
                                        
                                </div>

                            </div>

                        </fieldset>
                    </form>

                </div>
            </div>
            <div class="row col-md-12">
                <?php 
                //Number of sign-ups each month per year
                
                if(isset($_POST['selectyear'])){
                    $selected_year = $_POST['selectyear'];
                } else {
                    $selected_year = 2014;
                }
                
                $sql_signup_per_month = "SELECT MONTH(`joined_date`) as Month,COUNT(`joined_date`) as NewSignUps FROM `members` WHERE YEAR(`joined_date`) = '".$selected_year."' GROUP BY MONTH(`joined_date`)";
                $result_monthly_signup = $con->query($sql_signup_per_month);
               
                ?>
                <div class="row">
                <div class="row col-md-12">
                <h3>Result</h3>
                
                </br></br>
                    <table border='1'>
                        <tr>
                            <th>Month</th>
                            <th>New Sign-ups</th>
                        </tr>
                        <?php while ($row = $result_monthly_signup->fetch_array()){ ?>
                        <tr>
                            <td><?php echo $row['Month'] ?></td>
                            <td><?php echo $row['NewSignUps'] ?></td>
                        </tr>
                        <?php }?>
                    </table>
                <h6>Below Graph is representing the total signups for the selected year <b><?php echo $selected_year;?></b> </h6>
                
                </br>
                </div>
                <?php include_once './linegraph.html'; ?>
            </div>
            </div>
        </div>
        <!-- /.container -->

        <!-- Footer -->
        <footer class="py-5 bg-dark">
            <div class="container">
                <p class="m-0 text-center text-white">Copyright &copy; Lisanka Nagahatenna 2019</p>
            </div>
            <!-- /.container -->
        </footer>

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    </body>

</html>
